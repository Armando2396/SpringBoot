package com.example.MywebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MywebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MywebAppApplication.class, args);
	}

}
