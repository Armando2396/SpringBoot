package com.example.MywebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MywebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
